$(document).ready(function() {
    $('#coin-slider').coinslider({ width: 1000, height: 440, navigation: true, delay: 5000 });
  });
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    
})