$('.menu-icon').click(function(){
	$('.mobile-menu').addClass('active');
	$('body').css("overflow", "hidden");
});
$('.menu-exit').click(function(){
	$('.mobile-menu').removeClass('active');
	$('body').css("overflow", "auto");
});
if(window.matchMedia('(min-width: 1025px)').matches)
{
$(document).on('scroll', function () {

	var scrollTop = $(window).scrollTop();
	console.log(scrollTop);

	if(scrollTop >= 800 ){
		$('.step1').addClass('rollIn')
	}
	if(scrollTop >= 1000 ){
		$('.step2').addClass('rollOut')
	}
	if(scrollTop >= 1300 ){
		$('.step3').addClass('rollIn')	
	}
	if(scrollTop >= 1500 ){
		$('.step4').addClass('rollOut')
	}
});
}
$(document).ready(function(){
    $(".button_enter").click(function(){
	$(".details").addClass("active_form");
	 $('.button_enter').removeClass('pulse');
    });
    $('.button_exit').click(function(){	
    $('.details').removeClass('active_form');
    $('.button_enter').addClass('pulse');
    });
});

$(function($) {
$.localScroll({
  duration: 1000,
  hash: false });
});
