$('.menu-icon').click(function(){
	$('.mobile-menu').addClass('active');
});
$('.menu-exit').click(function(){
	$('.mobile-menu').removeClass('active');
	
});
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:20,
    nav:true,
    items:1
           
         
});
$(function() {
    $( "#tabs" ).tabs();
  });
  
$('#somecomponent').locationpicker({
	
});
$(function($) {
$.localScroll({
  duration: 1000,
  hash: false });
});
