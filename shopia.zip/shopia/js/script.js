$('.menu-icon').click(function(){
	$('.mobile-menu').addClass('active');
});
$('.menu-exit').click(function(){
	$('.mobile-menu').removeClass('active');
	
});
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:20,
    nav:true,
    items:1

         
});
$('.owl-carousel2').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        640:{
            items:3
        },
        1291:{
            items:6
        }
    }
})
$(document).on('scroll', function () {

	var scrollTop = $(window).scrollTop();
	console.log(scrollTop);

	if(scrollTop >= 300 ){
		$('.free').addClass('translate')
        $('.support').addClass('translate-right')
        
	}
    if(scrollTop >= 800 ){
        $('.col-left').addClass('translate')
        $('.col-right').addClass('translate-right') 
    }
});

$(function() {
    $('.button-up').click(function(){
       $('html, body').animate({scrollTop:0}, 2000);
   });
});