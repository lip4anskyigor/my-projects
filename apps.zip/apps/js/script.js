$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    
})